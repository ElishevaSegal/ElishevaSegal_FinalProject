type IMessage = {
  name: string;
  email: string;
  message: string;
  _id?: string;
};
export { IMessage };
